

###########################################################
##################### CODE MONKEY #########################
###########################################################


Thanks for downloading the project files!
I hope you find them useful!


If they help you, consider getting my Courses or 
supporting on Patreon or grabbing the Game Bundle.

https://unitycodemonkey.com/courses.php



** Common Questions **

- How do I use the Project Files?
They come as a .unitypackage, so just import them 
into a project.

It's better to import into a empty project instead of 
directly into your own game project.


- I'm seeing errors related to LWRP or Light2D?
Some projects were made before Unity renamed LWRP into URP
so they contain the old namespaces, just change them 
into the Universal namespaces and everything should work.


- I'm seeing other errors?
Make sure you have these packages installed: Cinemachine,
URP, ProBuilder, 2D Sprite, TextMeshPro.

If you still see errors, maybe they're related to the
Unity version, if so, use the same version I use 
in the video.




If the Project Files help you, 
consider getting my Courses or supporting on Patreon or
grabbing my Game Bundle.


Thanks!
- Code Monkey
https://unitycodemonkey.com/













